# LOGBOOK

Print records - done
Print search result - need to fix 